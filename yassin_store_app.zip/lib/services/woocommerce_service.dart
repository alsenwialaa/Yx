import 'package:woocommerce_api/woocommerce_api.dart';

class WooCommerceService {
  final WooCommerceAPI api = WooCommerceAPI(
    url: 'https://yassin-store.com',
    consumerKey: 'ck_d16eacfc0128e1564f4ebc0e4e557bb5eeb2f762',
    consumerSecret: 'cs_de49252a87fad5166163863baae7e18c8cfc3800',
  );

  Future<List> getProducts({String? search}) async {
    final response = await api.getAsync('products', parameters: {'search': search});
    return response;
  }

  // TODO: add methods for cart, orders, account, notifications...
}
