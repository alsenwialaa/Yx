import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/woocommerce_service.dart';

class ProductSearchDelegate extends SearchDelegate {
  @override
  List<Widget>? buildActions(BuildContext context) {
    return [IconButton(icon: Icon(Icons.clear), onPressed: () => query = '')];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(icon: Icon(Icons.arrow_back), onPressed: () => close(context, null));
  }

  @override
  Widget buildResults(BuildContext context) {
    final service = Provider.of<WooCommerceService>(context, listen: false);
    return FutureBuilder<List>(
      future: service.getProducts(search: query),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
        final products = snapshot.data!;
        return ListView.builder(
          itemCount: products.length,
          itemBuilder: (context, index) {
            final p = products[index];
            return ListTile(
              leading: Image.network(p['images'][0]['src'], width: 50, fit: BoxFit.cover),
              title: Text(p['name']),
              subtitle: Text('\$${p['price']}'),
              onTap: () {
                // TODO: product detail
              },
            );
          },
        );
      },
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return Container();
  }
}
